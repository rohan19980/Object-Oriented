/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

/**
 *
 * @author ad3409z
 */
public class Note extends CommonCode{
    private int noteID = 0;
    private String course = "";
    private String date = "";
    private String note = "";
    
        
    public Note(){
        
    }
    public void setNoteID(int nid){
        noteID = nid;
    }
    
    public void setCourse(String crse){
        course = crse;
    }
           
     public void setDate(String dt){
        date = dt;
    }
     
      public void setNote(String nt){
        note = nt;
    }

    public int getNoteID() {
        return noteID;
    }

    public String getCourse() {
        return course;
    }

    public String getDate() {
        return date;
    }

    public String getNote() {
        return note;
    }
      
}
