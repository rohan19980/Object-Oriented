/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

import java.awt.Color;

/**
 *
 * @author ad3409z
 */
public class SetcolorDemo extends javax.swing.JFrame{

    private Color Color;
    
    public SetcolorDemo() {
        initComponets();
         
         getContentPane().setBackground(new Color(204,204,100));
    }

    private void initComponets() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
