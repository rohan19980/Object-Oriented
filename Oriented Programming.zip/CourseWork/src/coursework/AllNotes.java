/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;
import java.util.ArrayList;

/**
 *
 * @author ad3409z
 */
public class AllNotes extends CommonCode{
    private ArrayList <Note> allNotes = new ArrayList<>();
    private String crse = "";
    
    public AllNotes() {
        readAllNotes();
    }
//Read from file
    public void readAllNotes() {
        ArrayList<String> readNotes=new ArrayList<>();
        readNotes=readTextFile(appDir+"\\Notes.txt");
        System.out.println(readNotes.get(0));
        
        if("File not found".equals(readNotes.get(0))){}
        else{
            allNotes.clear();
            for(String str : readNotes){
                String[] tmp=str.split("\t");
                Note n = new Note();
                n.setNoteID(Integer.parseInt(tmp[0]));
                n.setCourse(tmp[1]);
                n.setDate(tmp[2]);
                n.setNote(tmp[3]);
                allNotes.add(n);
            }
        }
        
    }
    
    public void addANote(int noteID, String course, String note) {
        Note myNote = new Note();
        myNote.setNoteID(noteID);
        myNote.setCourse(course);
        myNote.setNote(note);
        myNote.setDate(getDateAndTime());
        allNotes.add(myNote);
        //writeAllNotes();
        
    }
    
   
    
    
    
//Write in a file   
    public void writeAllNotes(){
        String path=appDir+"\\Notes.txt";
        ArrayList <String> writeNote =new ArrayList<>();
        
        for(Note n : allNotes){
            String tmp =n.getNoteID()+"\t";
            tmp += n.getCourse()+"\t";
            tmp += n.getDate()+"\t";
            tmp += n.getNote();
            writeNote.add(tmp);
        }
        
        try {
            writeTextFile(path, writeNote);
        }catch(Exception e){
            System.out.println("Problem! "+path);
            
        }
    }
    

    
    public ArrayList<Note> getAllNotes() {
        return allNotes;
    }

    String searchAllNotesByKeyword(String string, int i, String text) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    
    

}
